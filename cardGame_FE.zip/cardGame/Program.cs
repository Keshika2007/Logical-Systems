﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length != 1 || !int.TryParse(args[0], out int numberOfPeople) || numberOfPeople < 1 || numberOfPeople > 52)
        {
            Console.WriteLine("Input value does not exist, or value is invalid.");
            return;
        }

        // Initialize deck
        var suits = new[] { 'S', 'H', 'D', 'C' };
        var ranks = new[] { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };

        var deck = new List<string>();
        foreach (var suit in suits)
        {
            foreach (var rank in ranks)
            {
                deck.Add($"{suit}-{rank}");
            }
        }

        // Shuffle deck
        var random = new Random();
        deck = deck.OrderBy(x => random.Next()).ToList();

        // Distribute cards
        var cardDistribution = new Dictionary<int, List<string>>();
        for (int i = 0; i < numberOfPeople; i++)
        {
            cardDistribution[i] = new List<string>();
        }

        for (int i = 0; i < deck.Count; i++)
        {
            cardDistribution[i % numberOfPeople].Add(deck[i]);
        }

        // Output results as JSON
        var result = cardDistribution.ToDictionary(
            kvp => kvp.Key + 1,
            kvp => kvp.Value
        );

        Console.WriteLine(JsonSerializer.Serialize(result));
    }
}
